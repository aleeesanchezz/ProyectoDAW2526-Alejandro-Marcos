package com.proyecto.ecotrack_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcotrackBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
